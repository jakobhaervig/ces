---
name: My interesting presentation #Change this to the name of your presentation
number: ABCD-XXX #Change this to your group number, e.g. TEPE-700
categories: 
  - ABCD #Change this to your specialisation, e.g. TEPE, HYTEC, MCE, EPSH, PED or HWPS
  - Technical presentation #Don't delete this
---

Write abstract here in markdown format (max 200 words). You may write superscripts as <sup>this</sup> and subscripts like <sub>this</sub>. Italic text can be written as *this*. When you done writing your abstract, you should save this file using the group number from above, e.g. "TEPE-700.md".